﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class level2movemnt : MonoBehaviour
{
    public float MovementSpeed;
    Rigidbody rb;


    private Vector3 moveDirection = Vector3.zero;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        // Get the direction based on the user input
        moveDirection = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));
        moveDirection.Normalize();

        // Set the velocity to the direction * movement speed
        rb.velocity = new Vector3(moveDirection.x * MovementSpeed,
                                  rb.velocity.y,
                                  moveDirection.z * MovementSpeed);
    }
    public void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "coin")
        {
            SceneManager.LoadScene("win");
        }
    }
}
